let test = [
  {
    id: "test-id-1",
    name: "test-name-1",
    type: "test-type-1",
    group: [
      {
        id: "test-id-1-1",
        name: "test-name-1-1",
        type: "test-type-1-1",
        group: [
          {
            id: "test-id-1-1-1",
            name: "test-name-1-1-1",
            type: "test-type-1-1-1",
            group: [
              // there will be more test objectsḍ
            ],
          },
        ],
      },
      {
        id: "test-id-1-2",
        name: "test-name-1-2",
        type: "test-type-1-2",
        group: [
          {
            id: "test-id-1-2-1",
            name: "test-name-1-2-1",
            type: "test-type-1-2-1",
            group: [
              // there will be more test objects
            ],
          },
        ],
      },
    ],
  },
  {
    id: "test-id-2",
    name: "test-name-2",
    type: "test-type-2",
    group: [
      {
        id: "test-id-2-1",
        name: "test-name-2-1",
        type: "test-type-2-1",
        group: [
          {
            id: "test-id-2-1-1",
            name: "test-name-2-1-1",
            type: "test-type-2-1-1",
            group: [
              // there will be more test objects
            ],
          },
        ],
      },
      {
        id: "test-id-2-2",
        name: "test-name-2-2",
        type: "test-type-2-2",
        group: [
          {
            id: "test-id-2-2-1",
            name: "test-name-2-2-1",
            type: "test-type-2-2-1",
            group: [
              // there will be more test objects
            ],
          },
        ],
      },
    ],
  },
];

const getAllNames = (data, names = new Set()) => {
  for (const item of data) {
    names.add(item.name);
    if (item.group && item.group.length > 0) {
      getAllNames(item.group, names);
    }
  }
  return Array.from(names);
};
console.log(getAllNames(test));

// count the total object
const countObj = (data) => {
  let count = 0;
  for (let item of data) {
    count++;
    if (item.group && item.group.length > 0) {
      count += countObj(item.group);
    }
  }
  return count;
};
console.log(countObj(test));

// find by id
const findById = (data, Id) => {
  for (let x of data) {
    if (x.id === Id) {
      return x;
    }
    if (x.group && x.group.length > 0) {
      const datas = findById(x.group, Id);
      if (datas) return datas;
    }
  }
  return null;
};
console.log(findById(test, "test-id-1-1"));

// const isPalindrome = (data) => {
//   const update = data
//     .toLowerCase()
//     .split("")
//     .filter((datas) => /[a-z0-9]/.test(datas));
//   return update.join("") === update.reverse().join("");
// };
// console.log(isPalindrome("C1 O$d@eeD o1c"));

const age = () => {};
console.log(age(19));

const getAllNames1 = (data, names = new Set()) => {
  for (const item of data) {
    names.add(item.name);
    if (item.group && item.group.length > 1) {
      getAllNames1(item.group, names);
    }
  }
  return Array.from(names);
};
console.log("gg", getAllNames1(test));
