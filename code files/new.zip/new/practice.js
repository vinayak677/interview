// reverse string
const reverseString = (str) => {
  return str.split("").reverse().join("");
};
console.log(reverseString("javascript"));

// check number is prime
const isPrime = (num) => {
  if (num < 2) return false;
  for (let i = 2; i * i < num; i++) {
    if (num[i] % 2 === 0) {
      return false;
    }
  }
  return true;
};
console.log(isPrime(13));

//find large
const largNum = (num) => {
  return Math.max(...num);
};
console.log(largNum([1, 2, 3, 4, 5, 6, 7, 8]));

const maxx = (num) => {
  let max = num[0];
  for (let i = 1; i < num.length; i++) {
    if (num[i] > max) {
      max = num[i];
    }
  }
  return max;
};
console.log(maxx([1, 3, 55, 7, 9, 44]));

// fibonacci
const fibonacci = (num) => {
  const data = [0, 1];
  for (let i = 2; i < num; i++) {
    data.push(data[i - 1] + data[i - 2]);
  }
  return data;
};

console.log(fibonacci(5));

// palindrome
const palidrome = (str) => {
  return str.split("").reverse().join("");
};
console.log(palidrome("madam"));

// vowel count
const countVowel = (str) => {
  const vowels = "aeiou";
  let count = 0;
  for (let i = 0; i < str.length; i++) {
    if (vowels.includes(str[i])) {
      count++;
    }
  }
  return count;
};
console.log(countVowel("vinayak"));

// remove duplicate
const remDuplicate = (num) => {
  return num.filter((item, index) => num.indexOf(item) !== index);
};
console.log(remDuplicate([1, 2, 3, 4, 2, 3, 8, 5, 6, 7, 8]));

//flatten arr
const flatten = (num) => {
  return num.flat(Infinity);
};
console.log(flatten([1, [2, [3, 4], 5]]));

// missing number
const missingNum = (num) => {
  for (let i = 0; i < num.length; i++) {
    if (num[i + 1] - num[i] > 1) {
      return num[i] + 1;
    }
  }
};
console.log(missingNum([7, 8, 10, 11]));

// find duplicate
const findDuplicate = (num) => {
  return num.filter((item, index) => num.indexOf(item) !== index);
  //   return [...new Set(num)];
};
console.log(findDuplicate([1, 2, 3, 2, 4, 5, 65, 4, 7, 33, 65]));

// merge sorted arr
const sorted = (a, b) => {
  return [...a, ...b].sort((a, b) => a - b);
};
console.log(sorted([1, 3, 4], [6, 7, 9]));

// Fahrenheit to Celsius

const ferCel = (fer) => ((fer - 32) * 5) / 9;
console.log(ferCel(98));

// intersection of 2 arr
const findInter = (a, b) => a.filter((num) => b.includes(num));
console.log(findInter([1, 2, 3], [2, 3, 4]));

// Check if Two Strings are Anagrams
const anagrams = (str1, str2) => {
  const sortstr = (str) => str.split("").sort().join("");
  return sortstr(str1) === sortstr(str2);
};
console.log(anagrams("listen", "silent"));

// ECMA2023
// findLast
const temp = [27, 28, 45, 30, 40, 42, 49, 35, 30];
let high = temp.findLast((x) => x > 40);

console.log(high);
let highIndex = temp.findLastIndex((x) => x > 40);
console.log(highIndex);

// toReversed
const months = ["Jan", "Feb", "Mar", "Apr"];
const reverseMonths = months.toReversed();
console.log(months);
console.log(reverseMonths);

// toSorted
const sorteds = months.toSorted();
console.log(sorteds);

// toSpliced
const spliced = months.toSpliced(0, 1);
console.log(spliced);

const week = ["monday", "tuesday", "wed", "thursday"];
// week[2] = "Wednesday";
// console.log(week);

// const chang = (str) => {
//   for (let i = 0; i < str.length; i++) {
//     if (str[i] === "wed") {
//       str[i] = "wedn";
//     }
//   }
//   return str;
// };
// console.log(chang(week));

// with()
const updateWeeks = week.with(2, "Wedn");
console.log(updateWeeks);

let arr = [1, 3, -5, 5, 9, -9, -9];

function maxProduct(arr) {
  let currentSum = arr[0];
  let maxSum = arr[0];
  for (let i = 1; i < arr.length; i++) {
    if (currentSum < 0) {
      currentSum = arr[i];
      maxSum = maxSum < currentSum ? currentSum : maxSum;
    } else {
      currentSum += arr[i];
      maxSum = maxSum < currentSum ? currentSum : maxSum;
    }
  }
  return maxSum;
}
console.log(maxProduct(arr));

// fizzBuzz

function fizzBuzz(num) {
  for (let i = 1; i <= num; i++) {
    if (i % 3 === 0 && i % 5 === 0) {
      console.log("fizzBuzz");
    } else if (i % 3 === 0) {
      console.log("fizz");
    } else if (i % 5 === 0) {
      console.log("buzz");
    } else {
      console.log(i);
    }
  }
}

console.log(fizzBuzz(15));

const findMiss = (num) => {
  for (let i = 0; i < num.length; i++) {
    if (num[i + 1] - num[i] > 1) {
      return num[i] + 1;
    }
  }
};
console.log(findMiss([1, 2, 3, 5, 6]));

// is sorted
const isSorted = (num) => {
  for (let i = 0; i < num.length; i++) {
    if (num[i] > num[i + 1]) return false;
  }
  return true;
};
console.log(isSorted([1, 2, 3, 4, 5, 6, 7]));

// secLarge
const large = (num) => {
  max = num[0];
  for (let i = 1; i < num.length; i++) {
    if (num[i] > max) {
      max = num[i];
    }
  }
  return max;
};
console.log(large([1, 2, 12, 3, 4, 66, 7, 55]));

const secLarge = (num) => {
  let data = num.sort((a, b) => a - b);
  return data[data.length - 2];
};
console.log(secLarge([1, 2, 12, 3, 4, 66, 7, 55]));

const numbers = [10, 20, 30];
// for of
for (let x of numbers) {
  console.log(x * 2);
}
// for in
for (let x in numbers) {
  console.log("index", x, "values", numbers[x]);
}

const word = "hello";
for (let x of word) {
  console.log(x);
}

const person = { name: "vk", age: 25 };
for (let x in person) {
  console.log(x, person[x]);
}

const a = [1, 2, 3];
const b = a.filter((ele) => ele * 2);
console.log(b);

const miss = (num) => {
  const data = [];
  for (let i = 0; i < num.length; i++) {
    if (num[i + 1] - num[i] > 1) {
      data.push(num[i] + 1);
    }
  }
  return data;
};
console.log(miss([1, 2, 3, 4, 6]));

const sor = (num) => {
  for (let i = 0; i < num.length; i++) {
    if (num[i + 1] < num[i]) return false;
  }
  return true;
};
console.log(sor([1, 2, 3, 4, 7]));

// dupli
const dupli = (num) => {
  return num.filter((a, b) => num.indexOf(a) !== b);
};
console.log(dupli([1, 2, 3, 2, 4, 5, 3]));

// fabic
const fab = (num) => {
  const data = [0, 1];
  for (let i = 2; i < num; i++) {
    data.push(data[i - 1] + data[i - 2]);
  }
  return data;
};
console.log(fab(5));

//miss
const missed = (num) => {
  for (let i = 0; i < num.length; i++) {
    if (num[i + 1] - num[i] > 1) {
      return num[i] + 1;
    }
  }
};
console.log(missed([1, 2, 4, 5, 6]));

// prime
const prime = (num) => {
  if (num < 2) return false;
  for (let i = 2; i * i <= num; i++) {
    if (num % i === 0) {
      return false;
    }
  }
  return true;
};
console.log(prime(13));

// 2merge

const merge = (a, b) => {
  return a.filter((data) => b.includes(data));
};
console.log(merge([1, 2, 3], [3, 4, 5]));

const fizzBuzz2 = (num) => {
  for (let i = 0; i <= num; i++) {
    if (i % 3 === 0 && i % 5 === 0) {
      console.log("fizzBuzz");
    } else if (i % 3 === 0) {
      console.log("fizz");
    } else if (i % 5 === 0) {
      console.log("Buzz");
    } else {
      console.log(i);
    }
  }
};
console.log(fizzBuzz2(15));

// async function fetchData() {
//   try {
//     const response = await fetch("https://");
//     if (!response.ok) {
//       throw new Error(`${response.status}`);
//     }
//     const data = await response.json();
//     console.log(data);
//     return data;
//   } catch (error) {
//     console.log(error.message);
//   }
// }
// fetchData();

// function datas() {
//   fetch("")
//     .then((response) => {
//       if (!response.ok) {
//         throw new Error(response.status);
//       }
//       return response.json();
//     })
//     .then((data) => {
//       console.log(data);
//       return fetch(`htpp/:${data.id}`)
//         .then((resp2) => {
//           if (!resp2.ok) {
//             throw new Error(resp2.status);
//           }
//           return resp2.json();
//         })
//         .then((data2) => {
//           console.log(data2);
//           return data2;
//         })
//         .catch(error);
//     })
//     .catch(error);
// }
// datas();

//
// duplicate

// merge

// prime

// miss

// fabi

// is sort

let arra = [1, 3, -5, 5, 9, -9, -9];

const abv = (num) => {
  let counttotal = num[0];
  let maxTotal = num[0];
  for (let i = 1; i < num.length; i++) {
    if (counttotal < 0) {
      counttotal = num[i];
      maxTotal = maxTotal < counttotal ? counttotal : maxTotal;
    } else {
      counttotal += num[i];
      maxTotal = maxTotal < counttotal ? counttotal : maxTotal;
    }
  }
  return maxTotal;
};
console.log(abv(arra));

let p1 = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve("hello");
  }, 2000);
});

async function fetchData() {
  const val = await p1;
  console.log("hi");
  console.log(val);
}
fetchData();

const fz = (num) => {
  for (let i = 0; i <= num; i++) {
    if (i % 3 === 0 && i % 5 === 0) {
      console.log("fizzFuzz");
    } else if (i % 3 === 0) {
      console.log("fizz");
    } else if (i % 5 === 0) {
      console.log("buzz");
    } else {
      console.log(i);
    }
  }
};
console.log(fz(15));

const isPalindrome = (num) => {
  let up1 = num
    .toLowerCase()
    .split("")
    .filter((data) => /[a-z1-9]/.test(data));
  return up1.reverse().join("") === up1.join("");
};
console.log(isPalindrome("C1 O$d@eeD o1c"));

// duplicate

// merge

// prime

// miss

// fabi

// is sort

const dup = (num) => {
  return num.filter((data, index) => num.indexOf(data) !== index);
};
console.log(dup([1, 2, 3, 1, , 4, 5, 6, 3]));

const mer = (a, b) => {
  return a.filter((data) => b.includes(data));
};
console.log(mer([1, 2, 3, 4], [3, 6, 7, 8]));

const pri = (num) => {
  if (num < 1) return false;
  for (i = 2; i * i < num; i++) {
    if (num % i === 0) return false;
  }
  return true;
};
console.log(pri(15));

const mis = (num) => {
  for (let i = 0; i < num.length; i++) {
    if (num[i + 1] - num[i] > 1) {
      return num[i] + 1;
    }
  }
};
console.log(mis([1, 2, 3, 5, 6, 7]));

const fabb = (num) => {
  const data = [0, 1];
  for (let i = 2; i < num; i++) {
    data.push(data[i - 1] + data[i - 2]);
  }
  return data;
};
console.log(fabb(5));

const sortt = (num) => {
  for (let i = 0; i < num.length; i++) {
    if (num[i + 1] < num[i]) {
      return false;
    }
  }
  return true;
};
console.log(sortt([1, 2, 3, 4, 5, 2]));

const zz = (num) => {
  return num.reduce((a, b) => {
    return a + b;
  }, 0);
};
console.log(zz([1, 2, 3, 4, 6, 8, 94, 5]));
