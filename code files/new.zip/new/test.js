const obje = {
  name: "vinayak",
  age: () => {
    console.log(this.name);
  },
};
let data = obje.age();

// constructor
// const Person = (name) => {
//   this.name = name;
// };
// const john = new Person("john");

const fruits = ["apple", "banana", "cherry", "date", "elderberry"];

const slicedFruits = fruits.slice(1, 3);
console.log(slicedFruits); // Output: ['banana', 'cherry']
console.log(fruits);

// call
const job = { position: "FE" };

const printName = function (name, age) {
  console.log(`name-${name},age-${age},position-${this.position}`);
};
printName.call(job, "VK", "30");

// apply
const printName2 = function (name, age) {
  console.log(`name-${name},age-${age},position-${this.position}`);
};
printName2.apply(job, ["PK", "28"]);

// bind
const printName3 = function (name, age) {
  console.log(`name-${name},age-${age},position-${this.position}`);
};
const binds = printName3.bind(job, "PS", "22");
binds();

// call back fun
// const data = fetch("")

function sampleFunction() {
  return new Promise((resolve, reject) => {
    resolve("result");
  });
}

sampleFunction().then((res) => {
  console.log(res);
});
sampleFunction();

function multiplyWith(x) {
  return function (y) {
    return x * y;
  };
}

const multiplyWithTen = multiplyWith(10);

const result = multiplyWithTen(3);

function ac() {
  return new Promise((resolve, reject) => {
    resolve("api response");
  });
}
ac().then((data) => {
  sampleFunction(data).then((data) => {});
});

function secCall() {
  return new Promise((resolve, reject) => {
    resolve("resolved");
  });
}

function firstCall() {
  return new Promise((resolve, reject) => {
    resolve("resolved");
  });
}

firstCall()
  .then((resp) => {
    return secCall();
  })
  .then((data) => {
    console.log(data);
  });
firstCall();

// async await

async function emp() {
  return "first called";
}
async function pay() {
  return "called";
}

async function bothcalled() {
  try {
    const data = await emp();
    console.log(data);

    const data2 = await pay();
    console.log(data2);
  } catch (error) {
    console.log("error occered", error);
  }
}

function mob() {
  return new Promise((res, rej) => {
    res("resolved");
  });
}

mob.then((resp) => {
  return console.log(resp);
});

const url = "https://api.example.com/data";

async function fetchData() {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`${response.status}`);
    }
    const data = await response.json();
    console.log(data);
    return data;
  } catch (error) {
    console.log(error);
  }
}
fetchData();

async function checks() {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`${response.status}`);
    }
    const data = response.json();
    console.log(data);

    const response2 = await fetch(
      `https://api.example.com/second-endpoint/${data.id}`
    );
    if (!response2.ok) {
      throw new Error(`${response2.status}`);
    }
    const data2 = response.json();
    console.log(data2);
    return { data, data2 };
  } catch (error) {
    console.log(error);
  }
}
checks();
